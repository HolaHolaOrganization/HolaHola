Canonical capture acknowledgement must distinguish durable source/projection
completion from search freshness. Save a durable indexing obligation before
acknowledging, but never wait for remote whole-record embeddings under a
capture lock.

**Why:** Large rolling episodes can require hundreds of remote requests after
each short append. Waiting for those requests caused foreground capture to
time out after canonical persistence but before acknowledgement, encouraging
unsafe source replay even though the dialogue was already saved.

**How to apply:** Reuse the existing indexer's durable source selection and
retry machinery. Coalesce edits, retain pending status on partial failure, and
clear the obligation only for the exact canonical version successfully built.
Search freshness is a separate observable state, not evidence of source loss.
