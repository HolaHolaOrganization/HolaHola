Capture indexing change (assigned task1740), implemented with explicit user
authorization to use this checkout after the ownership guard returned
unknown_stop.

Canonical dialogue, stable capture identities, exact source text, DB-first
episode writes, Markdown parity and independent outbox/acknowledgement
boundaries remain intact. Whole-episode indexing no longer runs under the
watchdog capture lock. A coalesced memory-index:pending tag is durable before
acknowledgement and atomic with episode content updates. The existing indexer
owns retries; the standalone watchdog invokes that same scanner without
awaiting remote work. Version-CAS completion retains newer pending edits;
transaction-scoped advisory locks serialize derived writes across hosts and
manual/legacy indexers without locking canonical source rows.

Verification: npm run typecheck passed; four unit tests and two real PostgreSQL
tests passed, including the actual three-arm builder with synthetic HTTP,
partial chunk failure, slow concurrent append, competing host lock, latest
hashes, idempotent zero-remote retry and missing-key pending status. Watchdog
capture attribution/Markdown/request-failure retry checks, hermetic inner-life
checks and record-exchange acknowledgement checks passed. New database tests
are wired into scripts/run-ci-test-steps.mjs and cannot use a remote shared DB.
See docs/episode-capture-indexing.md for commands and cadence (existing server
cycle is two hours; standalone watchdog attempts pending work after draining).

Recovery owner: main Luca [Replit], identified through the architecture
consultation and local 33-message verification artifact. No active recovery or
watchdog process was present when checked. No recovery process restart, source
replay or shared-live-episode mutation test was performed. The managed app was
started once for required startup verification; its existing pre-start restore
repaired the stale local Episode34 Markdown from canonical DB. That generated
episode diff is unrelated code churn, not an authored change to source dialogue.
App health endpoint and landing screenshot work. No publication, new secrets,
schema migrations, queue tables or production-indexing-disable seams.

Coordination notice thread b87f2a50-ea2c-4309-848e-20579097685b was read at
global1949/sequence1, with no replies/questions. It is a same-actor notice:
stored/not_applicable is NOT a delivered or accepted handoff. No external
collaborator response is outstanding. Refresh its final sequence immediately
before completion and record any late replies.
